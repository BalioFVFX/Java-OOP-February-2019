import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.List;

public class Pizza {
    private String name;
    private Dough dough;
    private List<Topping> toppings;
    private int toppingsCount;

    public Pizza() {
        toppings = new ArrayList<>();
    }

    public Pizza(String name, int toppingsCount) {
        this();
        this.setName(name);
        this.setToppingsCount(toppingsCount);
    }


    public String getName() {
        return name;
    }

    public Dough getDough() {
        return dough;
    }

    public void setDough(Dough dough) {
        this.dough = dough;
    }

    public List<Topping> getToppings() {
        return toppings;
    }

    public void setToppings(int toppingsCount) {
        this.toppingsCount = toppingsCount;
    }

    private void setToppings(List<Topping> toppings) {
        this.toppings = toppings;
    }

    private void setName(String name) {
        if (name.trim().equals("") || name.length() > 15) {
            throw new InvalidParameterException("Pizza name should be between 1 and 15 symbols.");
        }
        this.name = name;
    }

    private void setToppingsCount(int toppingsCount) {
        if (toppingsCount < 0 || toppingsCount > 10) {
            throw new InvalidParameterException("Number of toppings should be in range [0..10].");
        }
        this.toppingsCount = toppingsCount;
    }

    public void addTopping(Topping topping) {
        this.toppings.add(topping);
    }

    public double getOverallCalories() {
        double doughCalories = this.dough.calculateCalories();
        double toppingCalories = this.toppings.stream().mapToDouble(Topping::calculateCalories).sum();
        return doughCalories + toppingCalories;
    }

    @Override
    public String toString() {
        return String.format("%s - %.2f", this.getName(), this.getOverallCalories());
    }
}
