public interface Person extends Identifiable, Birthable {
    String getName();
    int getAge();
}
