package enums;

public enum MissionState {
    inProgress,
    Finished
}
