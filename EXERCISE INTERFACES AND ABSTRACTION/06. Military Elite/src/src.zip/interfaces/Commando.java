package interfaces;

import java.util.Set;

public interface Commando {
    Set<Mission> getMissions();
}
