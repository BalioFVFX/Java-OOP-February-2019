package interfaces;

import java.util.Set;

public interface LeutenantGeneral {
    Set<Private> getPrivates();
}
