package interfaces;

public interface Private extends Solider, Comparable<Private>{
    double getSalary();
}
