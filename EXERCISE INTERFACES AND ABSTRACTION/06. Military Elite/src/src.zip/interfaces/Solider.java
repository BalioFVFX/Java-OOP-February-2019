package interfaces;

public interface Solider {
    String getId();
    String getFirstName();
    String getLastName();
}
