package interfaces;

public interface Spy {
    String getCodeNumber();
}
