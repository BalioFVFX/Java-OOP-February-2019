package utilities;

public interface IPrinter {
}
