package interfaces;

public interface MyList extends AddRemovable {
    int getUsed();
}
