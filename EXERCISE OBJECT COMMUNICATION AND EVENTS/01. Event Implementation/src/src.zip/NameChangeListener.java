public interface NameChangeListener {
    void handleChangedName(NameChange event);
}
