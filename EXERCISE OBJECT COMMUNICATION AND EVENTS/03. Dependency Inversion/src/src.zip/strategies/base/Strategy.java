package strategies.base;

public interface Strategy {
    int calculate(int first, int second);
}
