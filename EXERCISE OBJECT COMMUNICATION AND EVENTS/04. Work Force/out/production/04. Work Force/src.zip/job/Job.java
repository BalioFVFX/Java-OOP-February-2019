package job;

import employees.base.Employee;
import listeners.JobListener;
import listeners.WeekListener;

import java.util.Objects;

public class Job implements WeekListener {
    private Employee employee;
    private int reamingHours;
    private String name;
    private JobListener jobListener;
    public boolean isDone;

    public Job(String name, int reamingHours, Employee employee) {
        this.setName(name);
        this.setReamingHours(reamingHours);
        this.setEmployee(employee);
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public int getReamingHours() {
        return reamingHours;
    }

    public void setReamingHours(int reamingHours) {
        this.reamingHours = reamingHours;
    }

    public void update(){
        this.reamingHours -= this.employee.work();

        if(this.reamingHours <= 0){
            isDone = true;
            jobListener.onJobComplete(this);
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void onPassWeek() {
        this.update();
    }

    public void setJobListener(JobListener jobListener){
        this.jobListener = jobListener;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Job job = (Job) o;
        return Objects.equals(name, job.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}
