package listeners;

public interface WeekListener {
    void onPassWeek();
}
