public interface Defensible {
    void defend();
}
