public interface OnSoldierKilledListener {
    void onKilled(Soldier soldier);
}
