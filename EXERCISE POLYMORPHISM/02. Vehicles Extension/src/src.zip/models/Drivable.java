package models;

public interface Drivable {
    String drive(double distance);
    void refill(double liters);
}