package models.food;

import models.food.base.Food;

public class Meat extends Food {
    public Meat(Integer quantity) {
        super(quantity);
    }
}
