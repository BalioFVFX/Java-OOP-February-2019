package pr0304Barracks.core;

import pr0304Barracks.Inject;
import pr0304Barracks.contracts.Executable;
import pr0304Barracks.contracts.Repository;
import pr0304Barracks.contracts.UnitFactory;
import pr0304Barracks.core.commands.Command;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

public class CommandInterpreterImpl implements pr0304Barracks.contracts.CommandInterpreter {

    private static final String COMMAND_CLASS_NAME = "pr0304Barracks.core.commands.";

    private Repository repository;
    private UnitFactory unitFactory;

    public CommandInterpreterImpl(Repository repository, UnitFactory unitFactory) {
        this.repository = repository;
        this.unitFactory = unitFactory;
    }

    @Override
    public Executable interpretCommand(String[] data, String commandName) throws ClassNotFoundException, IllegalAccessException, InvocationTargetException, InstantiationException {
        final String className = COMMAND_CLASS_NAME + Character.toUpperCase(commandName.charAt(0)) + commandName.substring(1) + "Command";

        Class commandClass = Class.forName(className);
        Constructor<?> commandCTOR = commandClass.getDeclaredConstructors()[0];
        commandCTOR.setAccessible(true);
        Executable command = (Executable) commandCTOR.newInstance(new Object[]{data});

        Field[] executableFields = command.getClass().getDeclaredFields();
        Field[] thisFields = this.getClass().getDeclaredFields();
        for (Field executableField : executableFields) {
            if(executableField.isAnnotationPresent(Inject.class)){
                for (Field thisField : thisFields) {
                    if(executableField.getType().equals(thisField.getType())){
                        executableField.setAccessible(true);
                        executableField.set(command, thisField.get(this));
                    }
                }
            }
        }

        return command;
    }
}
