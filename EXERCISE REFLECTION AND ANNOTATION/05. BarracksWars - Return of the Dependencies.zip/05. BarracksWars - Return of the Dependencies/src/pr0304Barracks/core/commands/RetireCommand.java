package pr0304Barracks.core.commands;

import jdk.jshell.spi.ExecutionControl;
import pr0304Barracks.Inject;
import pr0304Barracks.contracts.Repository;
import pr0304Barracks.contracts.UnitFactory;

import java.lang.reflect.InvocationTargetException;
import java.security.InvalidParameterException;

public class RetireCommand extends Command {

    @Inject
    private Repository repository;

    protected RetireCommand(String[] data) {
        super(data);
    }

    @Override
    public String execute() throws ClassNotFoundException, InvocationTargetException, InstantiationException, ExecutionControl.NotImplementedException, IllegalAccessException {

        String unitType = super.getData()[1];
        try{
             this.repository.removeUnit(unitType);
         }
         catch (InvalidParameterException ex){
             return ex.getMessage();
         }
         return unitType+ " retired!";
    }
}
