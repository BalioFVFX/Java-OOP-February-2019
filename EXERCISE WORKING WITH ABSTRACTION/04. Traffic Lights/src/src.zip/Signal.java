public enum Signal {
    RED,
    YELLOW,
    GREEN;

}
