package commands.analyze;

import models.system.System;

public class Analyst {
    public static String analyze(System system){
        return system.analyze();
    }
}
