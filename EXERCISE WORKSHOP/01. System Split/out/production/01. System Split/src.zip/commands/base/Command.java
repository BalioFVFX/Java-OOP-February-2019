package commands.base;

public interface Command{
    void execute(String[] data);
}
