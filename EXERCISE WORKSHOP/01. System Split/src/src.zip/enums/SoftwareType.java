package enums;

public enum  SoftwareType {
    LIGHT_SOFTWARE,
    EXPRESS_SOFTWARE
}
