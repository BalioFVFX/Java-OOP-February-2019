package data.vehicles;

import model.boat.Boat;

public class BoatRepository extends BaseRepository<Boat> {
}
