package data.vehicles;

import model.engine.Engine;

public class EngineRepository extends BaseRepository<Engine> {
}
