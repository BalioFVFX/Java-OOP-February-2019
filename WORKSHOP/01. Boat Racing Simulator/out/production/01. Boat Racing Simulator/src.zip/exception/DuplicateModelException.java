package exception;

public class DuplicateModelException extends Exception {
    public DuplicateModelException(String message) {
        super(message);
    }
}
