package model.boat;

public interface Unique {
    String getModel();
}
