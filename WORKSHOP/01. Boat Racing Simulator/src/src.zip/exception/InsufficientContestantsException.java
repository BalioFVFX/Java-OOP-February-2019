package exception;

public class InsufficientContestantsException extends Exception{

    public InsufficientContestantsException(String message) {
        super(message);
    }
}
